-- Probably need more values here...

insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (236, N'AnalyticsDatabaseName', N'BPT')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (236, N'AnalyticsDatabasePassword', N'<devdata password>')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (236, N'AnalyticsDatabaseUserName', N'sa')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (236, N'AnalyticsDatabaseUserPassword', N'<devdata password>')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (236, N'EaiDatabaseName', N'BPT')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (236, N'EaiDatabasePassword', N'<devdata password>')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (236, N'EaiDatabaseUserName', N'sa')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (236, N'EaiDatabaseUserPassword', N'<devdata password>')


insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (227, N'EaiDatabaseName', N'EAI')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (227, N'EaiDatabasePassword', N'<devdata password>')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (227, N'EaiDatabaseUserName', N'BpUserDev1')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (227, N'EaiFtpDirectory', N'E:\FTP\LocalUser\EAI_TST')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (227, N'EaiFtpPassword', N'<devdata password>')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (227, N'EaiFtpPort', N'59022')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (227, N'EaiFtpUserName', N'EAI_TST')


insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (235, N'AzureStorageConnectionString', N'')
insert [dbo].[ServerParameter] ([ServerID], [ParameterKey], [ParameterValue]) values (235, N'AzureStoragePublicConnectionString', N'')