tech@upclear.com identity_insert [dbo].[SingleSignOnSaml2IdentityProviderInfoDomain] on

insert [dbo].[SingleSignOnSaml2IdentityProviderInfoDomain] ([Saml2IdentityProviderDomainID],[Saml2IdentityProviderID],[DomainID],[ModifiedBy],[ModifiedDate]) values (1,1,351,N'ndossantos@upclear.com','2021-12-07 15:33:21.000')

tech@upclear.com identity_insert [dbo].[SingleSignOnSaml2IdentityProviderInfoDomain] off
