set identity_insert [dbo].[SingleSignOnCredentialMapping] on

insert [dbo].[SingleSignOnCredentialMapping] ([CredentialMappingID],[DomainID],[SourcePrincipalName],[LoginID],[Saml2IdentityProviderID],[ModifiedBy],[ModifiedDate]) values (1,351,'tech@upclear.com',26996,1,N'tech@upclear.com','2019-02-07 09:27:13.363')

set identity_insert [dbo].[SingleSignOnCredentialMapping] off
