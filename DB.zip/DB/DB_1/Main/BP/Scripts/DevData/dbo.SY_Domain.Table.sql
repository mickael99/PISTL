insert [dbo].[SY_Domain] ([DomainID], [DomainName], [ParentCompany], [CreatedDate], [ModifiedDate], [ModifiedBy]) values (351, N'WWBP5', null, CAST(N'2020-03-24T14:00:10.170' as DateTime), CAST(N'2020-03-24T14:00:10.170' as DateTime), N'tech@upclear.com')
GO
