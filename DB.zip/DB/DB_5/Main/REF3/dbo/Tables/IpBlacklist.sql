﻿create table [dbo].[IpBlacklist] (
    [IP] VARCHAR (50) not null
);

